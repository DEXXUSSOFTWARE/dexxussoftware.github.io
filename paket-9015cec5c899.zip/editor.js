/* DEXXUS WEB Shield – Schwärz-Editor für PDF, Scans, Fotos und Pläne.
   Zeigt die Seitenbilder mit Balken über den von Shield gefundenen Angaben. Eigene Rechtecke, Kopf-/Fusszeile, Plankopf,
   Vorlagen. Export eingebrannt: PDF aus reinen Bildern (keine Textebene, keine Metadaten) oder JPG.
   Daten kommen aus der Seitenleiste (window.shieldFuerEditor über chrome.extension.getViews).
   Testmodus ohne Erweiterung: editor.html?test=1 (Datei wählen, wird lokal gelesen). */
"use strict";
const $ = id => document.getElementById(id);
const SCHWARZ = "#1E293B", PUNKT_PRO_PX = 72 / 150;      // Seitenbilder sind mit 150 dpi gerendert
let DOK = null, BALKEN = [], VERLAUF = [], ZOOM = 1, WERKZEUG = null, GEWAEHLT = null, NACHHER = true;
let nextId = 1;

function meldung(t, ms) {
  const m = $("meldung"); m.textContent = t; m.hidden = false;
  clearTimeout(meldung.t); meldung.t = setTimeout(() => { m.hidden = true; }, ms || 3500);
}
const speicher = {
  get: k => new Promise(ok => { try { chrome.storage.local.get(k, r => ok(r[k])); } catch (e) { try { ok(JSON.parse(localStorage.getItem(k))); } catch (e2) { ok(null); } } }),
  set: (k, v) => { try { chrome.storage.local.set({ [k]: v }); } catch (e) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e2) { /* ohne Speicher */ } } }
};

/* ---------- Treffer: gefundene Angaben auf Wortpositionen abbilden ---------- */
const norm = s => s.toLowerCase().normalize("NFC").replace(/[^\p{L}\p{N}]/gu, "");
function treffer(dok, karte, eigene, datum) {
  const aus = [];
  for (const s of dok.seiten) {
    if (!s.woerter || !s.woerter.length || !s.text) continue;
    const k = Object.assign({}, karte || {});
    ShieldEngine.anonymisieren(s.text, eigene || [], k, { datum: datum !== false });
    const originale = [...new Set(Object.values(k).concat(eigene || []))].filter(o => o && o.trim().length >= 2);
    const W = s.woerter.map(w => norm(w.t));
    for (const o of originale) {
      const teile = o.split(/\s+/).map(norm).filter(Boolean);
      if (!teile.length) continue;
      for (let i = 0; i < W.length; i++) {
        let j = 0, p = i, rest = "";
        // Wort für Wort vergleichen; ein Wort darf mehrere Teile enthalten (z. B. «CH9300762011»)
        while (j < teile.length && p < W.length) {
          const w = rest || W[p];
          if (!w) { p++; continue; }
          if (w === teile[j]) { j++; p++; rest = ""; }
          else if (w.startsWith(teile[j])) { rest = w.slice(teile[j].length); j++; if (!rest) p++; }
          else if (teile[j].startsWith(w) && !rest) { teile.splice(j, 1, w, teile[j].slice(w.length)); }
          else break;
        }
        if (j === teile.length && p > i) {
          const ws = s.woerter.slice(i, rest ? p + 1 : p);
          const zeilen = {};
          ws.forEach(w => (zeilen[w.zeile] = zeilen[w.zeile] || []).push(w));
          for (const z of Object.values(zeilen)) {
            const x0 = Math.min(...z.map(w => w.x)), y0 = Math.min(...z.map(w => w.y));
            const x1 = Math.max(...z.map(w => w.x + w.w)), y1 = Math.max(...z.map(w => w.y + w.h));
            const pad = Math.max(2, (y1 - y0) * 0.12);
            aus.push({ seite: s.nr, x: x0 - pad, y: y0 - pad, w: x1 - x0 + 2 * pad, h: y1 - y0 + 2 * pad, quelle: "treffer", text: o, an: true });
          }
          i = p - 1;
        }
      }
    }
  }
  // doppelte (gleiche Stelle) entfernen
  const ein = [];
  for (const b of aus) if (!ein.some(e => e.seite === b.seite && Math.abs(e.x - b.x) < 3 && Math.abs(e.y - b.y) < 3 && Math.abs(e.w - b.w) < 3)) ein.push(b);
  return ein;
}

/* ---------- Anzeige ---------- */
function seitenZeigen() {
  const main = $("seiten"); main.innerHTML = "";
  const breiteVerf = Math.min(window.innerWidth - 60, 1100);
  for (const s of DOK.seiten) {
    if (!s.bild) continue;
    const f = breiteVerf / s.breite * ZOOM;
    const el = document.createElement("div");
    el.className = "seite" + (NACHHER ? " nachher" : "") + (WERKZEUG === "rechteck" ? " ziehen" : "");
    el.style.width = Math.round(s.breite * f) + "px"; el.style.height = Math.round(s.hoehe * f) + "px";
    el.dataset.nr = s.nr; el.dataset.f = f;
    el.innerHTML = '<div class="nr">Seite ' + s.nr + ' von ' + DOK.seiten.length + '</div><img alt="" src="' + s.bild + '">';
    main.appendChild(el);
    seiteZiehen(el, s, f);
  }
  balkenZeigen();
}
function balkenZeigen() {
  document.querySelectorAll(".seite").forEach(el => {
    el.querySelectorAll(".b").forEach(b => b.remove());
    const nr = +el.dataset.nr, f = +el.dataset.f;
    BALKEN.filter(b => b.seite === nr).forEach(b => {
      const d = document.createElement("div");
      d.className = "b " + (b.quelle === "treffer" ? (b.an ? "treffer" : "aus") : "eigen") + (GEWAEHLT === b.id ? " gewaehlt" : "");
      Object.assign(d.style, { left: b.x * f + "px", top: b.y * f + "px", width: b.w * f + "px", height: b.h * f + "px" });
      d.title = b.quelle === "treffer" ? (b.text + (b.an ? " – wird geschwärzt (anklicken = nicht schwärzen)" : " – wird NICHT geschwärzt")) : "Eigener Balken – ziehen = verschieben, Ecke = Grösse, Entf = löschen";
      if (b.quelle !== "treffer") d.innerHTML = '<span class="griff"></span><button class="weg" title="Balken löschen">x</button>';
      d.addEventListener("mousedown", e => balkenMaus(e, b, f));
      el.appendChild(d);
    });
  });
  const an = BALKEN.filter(b => b.an).length;
  $("zaehler").textContent = an + " Balken werden geschwärzt";
}

function merken() { VERLAUF.push(JSON.stringify(BALKEN)); if (VERLAUF.length > 80) VERLAUF.shift(); }
function rueckgaengig() { if (!VERLAUF.length) return meldung("Nichts mehr rückgängig zu machen."); BALKEN = JSON.parse(VERLAUF.pop()); GEWAEHLT = null; balkenZeigen(); }

function balkenMaus(e, b, f) {
  if (WERKZEUG === "rechteck") return;          // beim Ziehen eines neuen Rechtecks nicht stören
  e.stopPropagation(); e.preventDefault();
  if (e.target.classList.contains("weg")) { merken(); BALKEN = BALKEN.filter(x => x.id !== b.id); GEWAEHLT = null; return balkenZeigen(); }
  if (b.quelle === "treffer") { merken(); b.an = !b.an; return balkenZeigen(); }
  GEWAEHLT = b.id;
  const groesse = e.target.classList.contains("griff");
  const sx = e.clientX, sy = e.clientY, start = { x: b.x, y: b.y, w: b.w, h: b.h };
  let bewegt = false;
  const weiter = ev => {
    const dx = (ev.clientX - sx) / f, dy = (ev.clientY - sy) / f;
    if (!bewegt && Math.abs(dx) + Math.abs(dy) > 2) { merken(); bewegt = true; }
    if (!bewegt) return;
    if (groesse) { b.w = Math.max(6, start.w + dx); b.h = Math.max(6, start.h + dy); }
    else { b.x = start.x + dx; b.y = start.y + dy; }
    balkenZeigen();
  };
  const ende = () => { document.removeEventListener("mousemove", weiter); document.removeEventListener("mouseup", ende); balkenZeigen(); };
  document.addEventListener("mousemove", weiter); document.addEventListener("mouseup", ende);
  balkenZeigen();
}

function seiteZiehen(el, s, f) {
  el.addEventListener("mousedown", e => {
    if (WERKZEUG !== "rechteck") { GEWAEHLT = null; balkenZeigen(); return; }
    e.preventDefault();
    const r = el.getBoundingClientRect(), x0 = (e.clientX - r.left) / f, y0 = (e.clientY - r.top) / f;
    merken();
    const b = { id: nextId++, seite: s.nr, x: x0, y: y0, w: 1, h: 1, quelle: "rechteck", an: true };
    BALKEN.push(b); GEWAEHLT = b.id;
    const weiter = ev => {
      const x1 = (ev.clientX - r.left) / f, y1 = (ev.clientY - r.top) / f;
      b.x = Math.min(x0, x1); b.y = Math.min(y0, y1); b.w = Math.abs(x1 - x0); b.h = Math.abs(y1 - y0);
      balkenZeigen();
    };
    const ende = () => {
      document.removeEventListener("mousemove", weiter); document.removeEventListener("mouseup", ende);
      if (b.w < 6 || b.h < 6) { BALKEN = BALKEN.filter(x => x !== b); VERLAUF.pop(); }
      balkenZeigen();
    };
    document.addEventListener("mousemove", weiter); document.addEventListener("mouseup", ende);
  });
}

/* ---------- Werkzeuge ---------- */
function werkzeug(w) {
  WERKZEUG = WERKZEUG === w ? null : w;
  $("wRechteck").classList.toggle("an", WERKZEUG === "rechteck");
  document.querySelectorAll(".seite").forEach(el => el.classList.toggle("ziehen", WERKZEUG === "rechteck"));
  if (WERKZEUG === "rechteck") meldung("Jetzt mit der Maus ein Rechteck über die Stelle ziehen. Esc = fertig.");
}
function bereich(art) {
  merken();
  for (const s of DOK.seiten) {
    if (!s.bild) continue;
    const b = { id: nextId++, seite: s.nr, quelle: art, an: true };
    if (art === "kopf") Object.assign(b, { x: 0, y: 0, w: s.breite, h: s.hoehe * 0.12 });
    else if (art === "fuss") Object.assign(b, { x: 0, y: s.hoehe * 0.88, w: s.breite, h: s.hoehe * 0.12 });
    else Object.assign(b, { x: s.breite * 0.62, y: s.hoehe * 0.78, w: s.breite * 0.36, h: s.hoehe * 0.2 });   // Plankopf unten rechts
    BALKEN.push(b);
  }
  balkenZeigen();
  meldung(art === "plankopf" ? "Plankopf geschwärzt – Balken mit der Maus anpassen." : (art === "kopf" ? "Kopfzeile" : "Fusszeile") + " auf allen Seiten geschwärzt.");
}

async function vorlagenLaden() {
  const v = (await speicher.get("schwaerz_vorlagen")) || [];
  $("wVorlagen").innerHTML = '<option value="">Vorlage anwenden …</option>' + v.map((x, i) => '<option value="' + i + '">' + x.name.replace(/</g, "&lt;") + '</option>').join("");
  return v;
}
async function vorlageMerken() {
  const eigene = BALKEN.filter(b => b.quelle !== "treffer" && b.an);
  if (!eigene.length) return meldung("Zuerst eigene Balken ziehen (Rechteck, Kopfzeile, Plankopf …).");
  const name = prompt("Name der Vorlage, z. B. «Pläne Architekt Muster»:");
  if (!name) return;
  const v = (await speicher.get("schwaerz_vorlagen")) || [];
  const s1 = DOK.seiten.find(s => s.nr === eigene[0].seite);
  v.push({ name: name.trim(), erstellt: new Date().toISOString(), seitenVerhaeltnis: s1.breite / s1.hoehe,
    balken: eigene.filter(b => b.seite === s1.nr).map(b => ({ xRel: b.x / s1.breite, yRel: b.y / s1.hoehe, wRel: b.w / s1.breite, hRel: b.h / s1.hoehe })) });
  speicher.set("schwaerz_vorlagen", v); await vorlagenLaden();
  meldung("Vorlage «" + name.trim() + "» gespeichert.");
}
async function vorlageAnwenden(i) {
  const v = ((await speicher.get("schwaerz_vorlagen")) || [])[i]; if (!v) return;
  merken(); let n = 0;
  for (const s of DOK.seiten) {
    if (!s.bild || Math.abs(s.breite / s.hoehe - v.seitenVerhaeltnis) / v.seitenVerhaeltnis > 0.05) continue;
    v.balken.forEach(r => { BALKEN.push({ id: nextId++, seite: s.nr, x: r.xRel * s.breite, y: r.yRel * s.hoehe, w: r.wRel * s.breite, h: r.hRel * s.hoehe, quelle: "vorlage", an: true }); });
    n++;
  }
  balkenZeigen();
  meldung(n ? "Vorlage auf " + n + " Seite" + (n === 1 ? "" : "n") + " angewendet." : "Keine Seite mit passendem Format gefunden.");
}

/* ---------- Export (eingebrannt) ---------- */
function bildLaden(src) { return new Promise((ok, nok) => { const i = new Image(); i.onload = () => ok(i); i.onerror = nok; i.src = src; }); }
async function seiteEinbrennen(s) {
  const c = document.createElement("canvas"); c.width = s.breite; c.height = s.hoehe;
  const ctx = c.getContext("2d");
  ctx.drawImage(await bildLaden(s.bild), 0, 0, s.breite, s.hoehe);
  ctx.fillStyle = SCHWARZ;
  BALKEN.filter(b => b.an && b.seite === s.nr).forEach(b => ctx.fillRect(Math.floor(b.x), Math.floor(b.y), Math.ceil(b.w) + 1, Math.ceil(b.h) + 1));
  return c;
}
const alsJpeg = c => new Promise(ok => c.toBlob(b => ok(b), "image/jpeg", 0.9));

/* Minimales PDF: jede Seite ein JPEG-Bild, keine Textebene, kein Info-Eintrag (keine Metadaten) */
async function pdfBauen(seiten) {
  const enc = new TextEncoder(), teile = [], offs = [];
  let laenge = 0;
  const schreib = x => { const b = typeof x === "string" ? enc.encode(x) : x; teile.push(b); laenge += b.length; };
  const obj = (n, kopf, strom) => {
    offs[n] = laenge;
    schreib(n + " 0 obj\n" + kopf);
    if (strom) { schreib("\nstream\n"); schreib(strom); schreib("\nendstream"); }
    schreib("\nendobj\n");
  };
  schreib("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
  const n = seiten.length, kids = [];
  for (let i = 0; i < n; i++) kids.push((3 + i * 3) + " 0 R");
  obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
  obj(2, "<< /Type /Pages /Kids [" + kids.join(" ") + "] /Count " + n + " >>");
  for (let i = 0; i < n; i++) {
    const s = seiten[i], jpg = new Uint8Array(await s.blob.arrayBuffer());
    const pp = s.punkt || PUNKT_PRO_PX, W = (s.breite * pp).toFixed(2), H = (s.hoehe * pp).toFixed(2);
    const p = 3 + i * 3, inh = enc.encode("q " + W + " 0 0 " + H + " 0 0 cm /Im0 Do Q");
    obj(p, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + W + " " + H + "] /Resources << /XObject << /Im0 " + (p + 2) + " 0 R >> >> /Contents " + (p + 1) + " 0 R >>");
    obj(p + 1, "<< /Length " + inh.length + " >>", inh);
    obj(p + 2, "<< /Type /XObject /Subtype /Image /Width " + s.breite + " /Height " + s.hoehe + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpg.length + " >>", jpg);
  }
  const total = 3 + n * 3, xref = laenge;
  let x = "xref\n0 " + total + "\n0000000000 65535 f \n";
  for (let i = 1; i < total; i++) x += String(offs[i]).padStart(10, "0") + " 00000 n \n";
  schreib(x + "trailer\n<< /Size " + total + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
  return new Blob(teile, { type: "application/pdf" });
}
function dateiname(endung, nr) {
  const basis = (DOK.name || "Dokument").replace(/\.[^.]+$/, "").replace(/[\\/:*?"<>|]+/g, "_");
  return basis + "_geschwaerzt" + (nr ? "_Seite" + nr : "") + "." + endung;
}
function herunterladen(blob, name) {
  const url = URL.createObjectURL(blob);
  try {
    chrome.downloads.download({ url, filename: name, saveAs: true }, () => setTimeout(() => URL.revokeObjectURL(url), 60000));
  } catch (e) {
    const a = document.createElement("a"); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
}
async function exportPdf() {
  meldung("PDF wird erstellt …", 20000);
  const seiten = [];
  for (const s of DOK.seiten.filter(s => s.bild)) seiten.push({ breite: s.breite, hoehe: s.hoehe, blob: await alsJpeg(await seiteEinbrennen(s)),
    punkt: DOK.typ === "bild" ? (s.breite > s.hoehe ? 842 : 595) / s.breite : 0 });   // Fotos und Scans auf A4-Breite
  herunterladen(await pdfBauen(seiten), dateiname("pdf"));
  meldung("Geschwärztes PDF erstellt – nur Bilder, kein Text darunter, keine Metadaten.");
}
async function exportJpg() {
  const seiten = DOK.seiten.filter(s => s.bild);
  for (const s of seiten) herunterladen(await alsJpeg(await seiteEinbrennen(s)), dateiname("jpg", seiten.length > 1 ? s.nr : 0));
  meldung(seiten.length > 1 ? seiten.length + " JPG-Dateien erstellt." : "Geschwärztes JPG erstellt.");
}

/* ---------- Start ---------- */
function start(daten) {
  DOK = daten.dok;
  if (daten.farbe) document.body.dataset.farbe = daten.farbe;
  if (!DOK || !DOK.seiten.some(s => s.bild)) { $("seiten").innerHTML = '<div class="leer">Kein Dokument gefunden. Bitte in der Seitenleiste bei einem PDF oder Bild auf «Geschwärzte Kopie» klicken.</div>'; return; }
  $("dokName").textContent = DOK.name + " – geschwärzte Kopie";
  BALKEN = treffer(DOK, daten.karte, daten.eigene, daten.datum).map(b => Object.assign(b, { id: nextId++ }));
  VERLAUF = [];
  $("info").textContent = DOK.seiten.length + " Seite" + (DOK.seiten.length === 1 ? "" : "n") + (DOK.meta && DOK.meta.ocrVerwendet ? " · Texterkennung verwendet – Balken bitte prüfen" : "") + " · alles lokal, nichts wird hochgeladen";
  seitenZeigen();
  meldung(BALKEN.length + " Angaben gefunden und geschwärzt. Bitte prüfen, fehlende Stellen mit «Rechteck ziehen» ergänzen.", 6000);
}

$("wRechteck").onclick = () => werkzeug("rechteck");
$("wKopf").onclick = () => bereich("kopf");
$("wFuss").onclick = () => bereich("fuss");
$("wPlankopf").onclick = () => bereich("plankopf");
$("wZurueck").onclick = rueckgaengig;
$("wVorlageMerken").onclick = vorlageMerken;
$("wVorlagen").onchange = e => { if (e.target.value !== "") vorlageAnwenden(+e.target.value); e.target.value = ""; };
$("wKleiner").onclick = () => { ZOOM = Math.max(0.3, ZOOM / 1.25); seitenZeigen(); };
$("wGroesser").onclick = () => { ZOOM = Math.min(5, ZOOM * 1.25); seitenZeigen(); };
$("wNachher").onclick = () => { NACHHER = !NACHHER; $("wNachher").classList.toggle("an", NACHHER); $("wNachher").textContent = NACHHER ? "Nachher" : "Vorher"; seitenZeigen(); };
$("wPdf").onclick = () => exportPdf().catch(e => meldung("PDF konnte nicht erstellt werden: " + e.message, 6000));
$("wJpg").onclick = () => exportJpg().catch(e => meldung("JPG konnte nicht erstellt werden: " + e.message, 6000));
document.addEventListener("keydown", e => {
  if (e.key === "Escape") { if (WERKZEUG) werkzeug(WERKZEUG); GEWAEHLT = null; balkenZeigen(); }
  else if ((e.key === "Delete" || e.key === "Backspace") && GEWAEHLT) { merken(); BALKEN = BALKEN.filter(b => b.id !== GEWAEHLT); GEWAEHLT = null; balkenZeigen(); }
  else if (e.key.toLowerCase() === "z" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); rueckgaengig(); }
});
document.addEventListener("wheel", e => { if (!e.ctrlKey) return; e.preventDefault(); ZOOM = Math.min(5, Math.max(0.3, ZOOM * (e.deltaY < 0 ? 1.1 : 1 / 1.1))); seitenZeigen(); }, { passive: false });
window.addEventListener("resize", () => { clearTimeout(window._rz); window._rz = setTimeout(seitenZeigen, 200); });

vorlagenLaden();
(function () {
  const q = new URLSearchParams(location.search);
  if (q.get("test") === "auto") {   // automatischer Selbsttest (Entwicklung): meldet Ablauf an den lokalen Testserver
    const log = m => fetch("http://localhost:8766/log?" + encodeURIComponent(m)).catch(() => {});
    window.addEventListener("error", e => log("FEHLER " + e.message));
    window.addEventListener("unhandledrejection", e => log("FEHLER " + (e.reason && e.reason.message || e.reason)));
    const s = document.createElement("script"); s.src = "dokumente.js";
    s.onload = async () => {
      const t0 = Date.now(); log("start");
      try {
        const b = await (await fetch(q.get("datei"))).blob();
        const d = await ShieldDokumente.lesen(new File([b], q.get("datei").split("/").pop()), { fortschritt: (a, m) => log(((Date.now() - t0) / 1000).toFixed(1) + "s " + m) });
        log("FERTIG " + d.meta.dauerMs + "ms ocr=" + d.meta.ocrVerwendet + " zeichen=" + d.text.length);
      } catch (e) { log("FEHLER " + e.message); }
    };
    document.head.appendChild(s);
    return;
  }
  if (q.get("test")) {      // Testmodus: Datei lokal lesen, ohne Seitenleiste
    const s = document.createElement("script"); s.src = "dokumente.js"; document.head.appendChild(s);
    $("seiten").innerHTML = '<div class="leer">Testmodus: PDF oder Bild wählen<br><br><input type="file" id="testDatei" accept=".pdf,.png,.jpg,.jpeg,.webp"><div id="testFort"></div></div>';
    $("testDatei").onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      try {
        const dok = await ShieldDokumente.lesen(f, { fortschritt: (a, m) => { $("testFort").textContent = m; } });
        window.TEST_DOK = dok; start({ dok, karte: {}, eigene: [], datum: true });
      } catch (err) { $("testFort").textContent = "Fehler: " + err.message; }
    };
    return;
  }
  let daten = null;
  try {
    for (const v of chrome.extension.getViews()) if (v.shieldFuerEditor) { daten = v.shieldFuerEditor(q.get("id")); if (daten && daten.dok) break; }
  } catch (e) { /* nicht in der Erweiterung */ }
  start(daten || {});
})();
