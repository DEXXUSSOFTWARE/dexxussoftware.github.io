/* DEXXUS Shield – KI-Anschluss (läuft auf der KI-Seite).
   Bekommt von der Seitenleiste NUR den bereits geschwärzten Text, schreibt ihn ins Eingabefeld, klickt «Senden»,
   wartet auf die fertige Antwort und gibt deren Text zurück. Liest sonst nichts von der Seite. */
(() => {
  const VERSION = "0.2.0";
  if (window.__dexxusShieldAdapter === VERSION) return;
  window.__dexxusShieldAdapter = VERSION;
  if (/demo_ki\.html$/i.test(location.pathname)) document.documentElement.dataset.shield = "aktiv";   // nur Demo: Sichtkontrolle

  // Selektoren mit Ersatz-Möglichkeiten. Später über die Prüfstelle aktualisierbar (nur Daten, kein Code).
  const ANSCHLUESSE = {
    chatgpt: {
      name: "ChatGPT",
      eingabe: ["#prompt-textarea", "div[contenteditable='true'][data-virtualkeyboard]", "main div[contenteditable='true']", "textarea"],
      senden: ["[data-testid='send-button']", "#composer-submit-button", "button[aria-label*='Send']", "button[aria-label*='senden']", "button[aria-label*='Senden']"],
      antwort: ["[data-message-author-role='assistant']", "div.markdown", "[class*='markdown']", "article [class*='prose']"],
      laeuft: ["[data-testid='stop-button']", "button[aria-label*='Stop']", "button[aria-label*='stopp']"]
    },
    claude: {
      name: "Claude",
      eingabe: ["div[contenteditable='true'].ProseMirror", "fieldset div[contenteditable='true']", "div[contenteditable='true']"],
      senden: ["button[aria-label='Send message']", "button[aria-label*='Send']", "button[aria-label*='Nachricht senden']", "button[aria-label*='senden']"],
      antwort: [".font-claude-response", ".font-claude-message", "[data-testid='assistant-message']", "[data-is-streaming]", "[class*='font-claude']", "div.prose"],
      laeuft: ["[data-is-streaming='true']", "button[aria-label*='Stop']", "button[aria-label*='Antwort stoppen']"]
    },
    copilot: {
      name: "Copilot",
      eingabe: ["textarea#userInput", "textarea[data-testid='composer-input']", "textarea"],
      senden: ["button[data-testid='submit-button']", "button[aria-label*='Submit']", "button[aria-label*='Nachricht senden']", "button[aria-label*='Senden']", "button[title*='Submit']"],
      antwort: ["[data-content='ai-message']", "[data-testid='ai-message']", "div[class*='ai-message']", "[class*='markdown']"],
      laeuft: ["button[data-testid='stop-button']", "button[aria-label*='Stop']", "button[aria-label*='Beenden']"]
    },
    gemini: {
      name: "Gemini",
      eingabe: ["rich-textarea div[contenteditable='true']", "div.ql-editor[contenteditable='true']", "div[contenteditable='true']", "textarea"],
      senden: ["button.send-button", "button[aria-label*='Send']", "button[aria-label*='senden']", "button[aria-label*='Senden']"],
      antwort: ["model-response", "message-content", ".model-response-text", "[class*='markdown']"],
      laeuft: ["button[aria-label*='Stop']", "button[aria-label*='stopp']", "button[aria-label*='Antwort beenden']"]
    },
    perplexity: {
      name: "Perplexity",
      eingabe: ["#ask-input", "div[contenteditable='true']", "textarea"],
      senden: ["button[aria-label*='Submit']", "button[aria-label*='Senden']", "button[data-testid='submit-button']"],
      antwort: ["[id^='markdown-content']", "div.prose", "[class*='prose']"],
      laeuft: ["button[aria-label*='Stop']", "button[aria-label*='stopp']"]
    },
    demo: {
      name: "Demo-KI",
      eingabe: ["#eingabe"], senden: ["#senden"], antwort: [".antwort"], laeuft: [".laeuft"]
    }
  };

  function welcheKI() {
    const h = location.hostname;
    if (/demo_ki\.html$/i.test(location.pathname)) return "demo";
    if (h.endsWith("chatgpt.com") || h.endsWith("chat.openai.com")) return "chatgpt";
    if (h.endsWith("claude.ai")) return "claude";
    if (h.endsWith("copilot.microsoft.com")) return "copilot";
    if (h.endsWith("gemini.google.com")) return "gemini";
    if (h.endsWith("perplexity.ai")) return "perplexity";
    return null;
  }
  const warte = ms => new Promise(r => setTimeout(r, ms));
  const sichtbar = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  function finde(sels) {
    for (const s of sels || []) {
      const l = [...document.querySelectorAll(s)].filter(sichtbar);
      if (l.length) return l[l.length - 1];
    }
    return null;
  }
  function alle(sels) {
    for (const s of sels || []) { const l = document.querySelectorAll(s); if (l.length) return [...l]; }
    return [];
  }

  async function einfuegen(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value").set;
      setter.call(el, text);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    // contenteditable (ChatGPT, Claude): alles markieren, dann als «Einfügen» übergeben
    const sel = window.getSelection(), r = document.createRange();
    r.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(r);
    const dt = new DataTransfer(); dt.setData("text/plain", text);
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
    await warte(250);
    const ist = (el.innerText || "").replace(/\s+/g, "");
    const soll = text.replace(/\s+/g, "");
    if (ist.length < Math.min(soll.length, 30) * 0.8) {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, text);
    }
  }

  async function sendenKlicken(cfg, eingabe) {
    for (let i = 0; i < 40; i++) {                       // bis 8 s warten, bis der Knopf aktiv ist
      const k = finde(cfg.senden);
      if (k && !k.disabled && k.getAttribute("aria-disabled") !== "true") { k.click(); return; }
      await warte(200);
    }
    // Ersatz: Enter im Eingabefeld
    eingabe.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
  }

  // Ersatzweg: alles, was auf der Seite NACH der gesendeten Nachricht steht (unabhängig vom Seitenaufbau)
  const FUSSZEILEN = ["ChatGPT ist KI", "ChatGPT can make mistakes", "ChatGPT kann Fehler", "Claude can make mistakes", "Claude kann Fehler",
                      "Copilot kann Fehler", "Copilot may make mistakes", "Nachricht an Copilot", "Gemini kann Fehler", "Gemini can make mistakes",
                      "Gemini ist eine KI", "Frag Gemini", "Ask Gemini", "Ask a follow-up", "Folgefrage stellen", "Frag irgendwas", "Ask anything", "Antworten …", "Reply to Claude"];
  function textNachMarke(marke) {
    const wurzel = document.querySelector("main") || document.body;
    const alles = wurzel.innerText || "";
    const i = alles.lastIndexOf(marke);
    if (i < 0) return "";
    let t = alles.slice(i + marke.length);
    for (const f of FUSSZEILEN) { const j = t.indexOf(f); if (j >= 0) t = t.slice(0, j); }
    return t.split("\n").filter(z => !/^(Kopieren|Copy|Teilen|Share|Bearbeiten|Edit|Retry|Erneut|Gefällt mir|Schreiben|Writing|\d+ \/ \d+)$/i.test(z.trim())).join("\n").trim();
  }

  async function warteAufAntwort(cfg, vorher, vorherText, maxMs, marke) {
    const start = Date.now(); let letzter = "", stabilSeit = 0;
    while (Date.now() - start < maxMs) {
      await warte(500);
      const liste = alle(cfg.antwort);
      let neu = liste.length > vorher ? liste[liste.length - 1] : (liste.length && (liste[liste.length - 1].innerText || "") !== vorherText ? liste[liste.length - 1] : null);
      let t;
      if (neu) t = (neu.innerText || "").trim();
      else if (marke && Date.now() - start > 4000) t = textNachMarke(marke);   // Selektoren passen nicht → Ersatzweg
      else continue;
      if (!t) continue;
      const laeuft = !!finde(cfg.laeuft);
      if (t && t === letzter) {
        if (!stabilSeit) stabilSeit = Date.now();
        const ruhig = Date.now() - stabilSeit;
        if ((!laeuft && ruhig >= 2000) || ruhig >= 6000) return t;   // 6 s ohne Änderung = fertig, auch wenn ein «Stop»-Knopf stehen bleibt
      } else {
        stabilSeit = 0; letzter = t;
        if (t) chrome.runtime.sendMessage({ shield: true, typ: "teil", text: t }).catch(() => {});   // live an Shield
      }
    }
    if (letzter) return letzter;
    throw new Error("Keine Antwort der KI innert " + Math.round(maxMs / 1000) + " Sekunden.");
  }

  async function senden(text, anschluss) {
    const ki = welcheKI();
    if (!ki) throw new Error("Diese Seite ist keine unterstützte KI.");
    const cfg = Object.assign({}, ANSCHLUESSE[ki], anschluss || {});
    const eingabe = finde(cfg.eingabe);
    if (!eingabe) throw new Error(cfg.name + ": Eingabefeld nicht gefunden. Bist du angemeldet? Seite neu laden und nochmals versuchen.");
    const vorherListe = alle(cfg.antwort);
    const vorher = vorherListe.length, vorherText = vorher ? (vorherListe[vorher - 1].innerText || "") : "";
    await einfuegen(eingabe, text);
    await warte(300);
    await sendenKlicken(cfg, eingabe);
    const zeilen = text.split("\n").map(z => z.trim()).filter(z => z.length >= 12);
    const marke = zeilen.length ? zeilen[zeilen.length - 1].slice(-60) : "";
    return await warteAufAntwort(cfg, vorher, vorherText, 300000, marke);
  }

  chrome.runtime.onMessage.addListener((msg, sender, antworte) => {
    if (!msg || !msg.shield) return;
    if (msg.typ === "ping") {
      const ki = welcheKI();
      antworte({ ok: true, ki, name: ki ? ANSCHLUESSE[ki].name : null, bereit: ki ? !!finde(ANSCHLUESSE[ki].eingabe) : false });
      return;
    }
    if (msg.typ === "holen") {                            // Notfall: letzte Antwort sofort holen
      const ki = welcheKI(), cfg = ki ? Object.assign({}, ANSCHLUESSE[ki], msg.anschluss || {}) : null;
      const l = cfg ? alle(cfg.antwort) : [];
      const t = l.length ? (l[l.length - 1].innerText || "").trim() : "";
      antworte(t ? { ok: true, text: t } : { ok: false, fehler: "Auf der KI-Seite wurde keine Antwort gefunden." });
      return;
    }
    if (msg.typ === "senden") {
      senden(msg.text, msg.anschluss).then(t => antworte({ ok: true, text: t })).catch(e => antworte({ ok: false, fehler: e.message }));
      return true;                                        // Antwort kommt später
    }
  });
})();
