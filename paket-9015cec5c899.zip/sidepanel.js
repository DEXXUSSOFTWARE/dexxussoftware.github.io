/* DEXXUS Shield – Seitenleiste (Testversion 1, Layout 2 «Gross & einfach").
   Ablauf: eingeben → «Ausführen» → schwärzen (lokal) → an die KI → Antwort holen → echte Namen einsetzen → speichern. */
"use strict";
const IST_ERW = typeof chrome !== "undefined" && !!(chrome.runtime && chrome.runtime.id);
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const warte = ms => new Promise(r => setTimeout(r, ms));

/* ---------- Speicher (nur lokal auf diesem PC) ---------- */
const speicher = {
  async get(k, std) {
    if (IST_ERW && chrome.storage) { const r = await chrome.storage.local.get(k); return r[k] !== undefined ? r[k] : std; }
    try { const v = localStorage.getItem("shield_" + k); return v ? JSON.parse(v) : std; } catch (e) { return std; }
  },
  async set(k, v) {
    if (IST_ERW && chrome.storage) return chrome.storage.local.set({ [k]: v });
    try { localStorage.setItem("shield_" + k, JSON.stringify(v)); } catch (e) { /* ohne Speicher weiterarbeiten */ }
  }
};

let EINST = { ki: "auto", datum: true, hinweis: true, eigene: "", farbe: "blau" };
function farbeSetzen(f) {
  document.body.dataset.farbe = f || "blau";
  document.querySelectorAll("#eFarben button").forEach(b => b.classList.toggle("an", b.dataset.f === (f || "blau")));
}
document.querySelectorAll("#eFarben button").forEach(b => b.onclick = () => {      // sofort sichtbar und gespeichert
  farbeSetzen(b.dataset.f); EINST.farbe = b.dataset.f; speicher.set("einstellungen", EINST);
});
let SITZUNG = neueSitzung();
let DOKS = [];          // {id, name, text, fehler, laedt}
let UEB = [];           // gespeicherte Antworten, neueste zuerst
let WAHL = new Set();   // ausgewählte in der Übersicht
let lauf = 0;           // Nummer des laufenden Auftrags (für «Abbrechen»)

/* für den Schwärz-Editor (editor.html holt Dokument und Einstellungen über chrome.extension.getViews) */
window.shieldFuerEditor = id => ({ dok: (DOKS.find(d => d.id === id) || {}).dok || null, karte: SITZUNG.karte,
  eigene: (EINST.eigene || "").split(/\r?\n/).map(s => s.trim()).filter(s => s.length >= 2), datum: EINST.datum, farbe: EINST.farbe });

function neueSitzung() { return { karte: {}, eintraege: [], hinweisGesendet: false, dokNr: 0 }; }

/* ---------- Kleinigkeiten ---------- */
let meldTimer = null;
function meldung(t, ms) {
  const m = $("meldung"); m.textContent = t; m.hidden = false;
  clearTimeout(meldTimer); meldTimer = setTimeout(() => { m.hidden = true; }, ms || 3000);
}
async function kopieren(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch (e) {
    const t = document.createElement("textarea"); t.value = text; document.body.appendChild(t); t.select();
    const ok = document.execCommand("copy"); t.remove(); return ok;
  }
}
const datum = iso => new Date(iso).toLocaleString("de-CH", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
function stufe(n) {
  document.querySelectorAll(".stufe").forEach(s => {
    const k = +s.dataset.s; s.classList.toggle("an", k === n); s.classList.toggle("ok", k < n);
    s.querySelector("i").textContent = k < n ? "✓" : k;
  });
}
function oeffne(id) { $(id).hidden = false; }
document.querySelectorAll("[data-zu]").forEach(b => b.onclick = () => { b.closest(".fenster").hidden = true; });
document.querySelectorAll(".fenster").forEach(f => f.addEventListener("click", e => { if (e.target === f) f.hidden = true; }));

/* ---------- KI erkennen ---------- */
function kiAusUrl(u) {
  try {
    const url = new URL(u), h = url.hostname;
    if (/demo_ki\.html$/i.test(url.pathname)) return { id: "demo", name: "Demo-KI" };
    if (h.endsWith("chatgpt.com") || h.endsWith("chat.openai.com")) return { id: "chatgpt", name: "ChatGPT" };
    if (h.endsWith("claude.ai")) return { id: "claude", name: "Claude" };
    if (h.endsWith("copilot.microsoft.com")) return { id: "copilot", name: "Copilot" };
    if (h.endsWith("gemini.google.com")) return { id: "gemini", name: "Gemini" };
    if (h.endsWith("perplexity.ai")) return { id: "perplexity", name: "Perplexity" };
  } catch (e) { /* keine gültige Adresse */ }
  return null;
}
async function aktiverTab() {
  if (!IST_ERW) return null;
  const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return t || null;
}
async function kiAnzeigen() {
  const a = $("kiAnzeige");
  if (EINST.ki === "universal") { a.textContent = "Universal-Weg (jede KI)"; return; }
  if (!IST_ERW) { a.textContent = "Demo-Modus (ohne Erweiterung)"; return; }
  const t = await aktiverTab(), k = t && kiAusUrl(t.url || "");
  a.textContent = k ? "✓ verbunden mit " + k.name : "Keine KI-Seite offen";
}
if (IST_ERW) {
  chrome.tabs.onActivated.addListener(kiAnzeigen);
  chrome.tabs.onUpdated.addListener((id, info) => { if (info.url || info.status === "complete") kiAnzeigen(); });
}

/* ---------- An die KI senden ---------- */
async function anKI(text) {
  if (!IST_ERW) return demoKI(text);
  const t = await aktiverTab(), k = t && kiAusUrl(t.url || "");
  if (!k) throw new Error("Keine KI-Seite offen. Öffne ChatGPT, Claude, Copilot, Gemini oder Perplexity im aktiven Reiter – oder wähle unter ⚙ «Universal».");
  const nachricht = { shield: true, typ: "senden", text };
  let r;
  try { r = await chrome.tabs.sendMessage(t.id, nachricht); }
  catch (e) {                                                   // Seite war schon offen, bevor Shield geladen wurde
    try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["adapter.js"] }); }
    catch (e2) { throw new Error("Shield kann die KI-Seite nicht erreichen. Seite neu laden (F5) und nochmals versuchen."); }
    r = await chrome.tabs.sendMessage(t.id, nachricht);
  }
  if (!r) throw new Error("Keine Verbindung zur KI-Seite. Seite neu laden (F5) und nochmals versuchen.");
  if (!r.ok) throw new Error(r.fehler || "Unbekannter Fehler auf der KI-Seite.");
  return r.text;
}
async function demoKI(text) {                                   // nur ohne Erweiterung (Vorschau/Test)
  await warte(900);
  text = text.replace(/^Hinweis an die KI:[\s\S]*?\n\n/, "");
  const ph = [...new Set(text.match(/\[[A-Za-zÄÖÜäöü\-. ]+ \d+\]/g) || [])];
  const person = ph.find(p => p.startsWith("[Person")) || "Kundin";
  return "Gerne. Hier ist ein Entwurf:\n\nSehr geehrte Frau " + person + "\n\nWir beziehen uns auf Ihr Anliegen" +
    (ph.length > 1 ? " (" + ph.filter(p => p !== person).join(", ") + ")" : "") + ". Bitte melden Sie sich innert 10 Tagen.\n\nFreundliche Grüsse";
}

/* ---------- Status-Anzeige ---------- */
const SYM = { ok: "✓", lauf: '<span class="spin">◌</span>', warte: "○", wf: "⚠", ff: "✕" };
function statusSetzen(zeilen) {
  $("statusListe").innerHTML = zeilen.map(([art, t]) => '<div class="' + art + '"><span>' + SYM[art] + '</span><span>' + esc(t) + '</span></div>').join("");
}

/* ---------- Abo, Lizenz, Gratis-Grenze ---------- */
let LIZ = { start: null, zaehler: null, lizenz: null };
function bannerZeigen() {
  const s = ShieldLizenz.status(LIZ), b = $("aboBanner");
  b.className = "abo-banner" + (s.art === "abo" ? " ok" : s.art === "gratis" ? " werbung" : "");
  b.innerHTML = '<span>' + "" + esc(s.text) + '</span>' +
    '<button id="knopfAbo">' + (s.art === "abo" ? "Lizenz" : "Jetzt kaufen") + '</button>';
  $("knopfAbo").onclick = aboFenster;
  return s;
}
function aboFenster(grund) {
  const s = ShieldLizenz.status(LIZ);
  const st = $("lizStatus");
  st.className = "liz-status" + (s.art === "abo" ? " ok" : s.frei <= 0 ? " leer" : "");
  st.textContent = typeof grund === "string" ? grund : s.text;
  $("aboListe").innerHTML = ShieldLizenz.ABOS.map((a, i) => '<button class="abo' + (i === 2 ? ' beliebt' : '') + '" data-j="' + a.jahre + '">' +
    '<span><b>' + a.text + '</b><small>' + a.hinweis + (i === 2 ? ' · am günstigsten' : '') + '</small></span><span class="preis">CHF ' + a.chf + '</span></button>').join("");
  $("aboListe").querySelectorAll("[data-j]").forEach(k => k.onclick = () => {
    const url = ShieldLizenz.KAUF_URL + "&jahre=" + k.dataset.j;
    if (IST_ERW) chrome.tabs.create({ url }); else window.open(url, "_blank");
  });
  oeffne("fensterLizenz");
}
/* Nach der Gratis-Zeit: unter jeder Antwort ein Kauf-Banner */
function werbungNachAntwort() {
  const s = ShieldLizenz.status(LIZ);
  if (s.art !== "gratis") return;
  const w = ShieldLizenz.WERBUNG, d = document.createElement("div");
  d.className = "werbe-karte";
  d.innerHTML = '<b>' + esc(w[Math.floor(Math.random() * w.length)]) + '</b><span>Unbegrenzt mit ChatGPT, Claude, Copilot, Gemini &amp; Perplexity.</span>' +
    '<button class="gross">Jetzt kaufen</button>';
  d.querySelector("button").onclick = aboFenster;
  $("verlauf").appendChild(d);
}

async function lizenzUebernehmen(text) {
  const r = await ShieldLizenz.pruefen(text);
  if (!r.ok) { $("lizStatus").className = "liz-status leer"; $("lizStatus").textContent = "✕ " + r.fehler; return; }
  LIZ.lizenz = { daten: r.daten, text };
  await speicher.set("lizenz_status", LIZ);
  bannerZeigen(); $("fensterLizenz").hidden = true; $("lizText").value = "";
  meldung("✓ Abo aktiv" + (r.daten.bis && !r.daten.unbefristet ? " bis " + ShieldLizenz.datumCH(r.daten.bis) : "") + ". Danke!", 5000);
}
$("lizUebernehmen").onclick = () => { const t = $("lizText").value.trim(); if (!t) return meldung("Bitte Lizenz-Datei wählen oder Text einfügen."); lizenzUebernehmen(t); };
$("lizDatei").onchange = async e => { const f = e.target.files[0]; e.target.value = ""; if (f) lizenzUebernehmen(await f.text()); };

/* ---------- Ausführen ---------- */
async function ausfuehren() {
  if (DOKS.some(d => d.laedt)) return meldung("Dokument wird noch gelesen …");
  const st = ShieldLizenz.status(LIZ);
  if (st.frei <= 0) return aboFenster("Ihre Gratis-Zeit ist vorbei. Jetzt kaufen und sofort unbegrenzt weiterarbeiten – ab CHF 9.90/Monat.");
  const text = $("textFeld").value.trim(), frage = $("frageFeld").value.trim();
  const doks = DOKS.filter(d => !d.fehler && d.text);
  if (!text && !frage && !doks.length) return meldung("Bitte Text, Dokument oder Frage eingeben.");

  const meinLauf = ++lauf;
  $("eingabe").hidden = true; $("arbeitet").hidden = false; $("universal").hidden = true; stufe(2);
  const zeilen = [["lauf", "Schwärzen …"], ["warte", "An die KI senden"], ["warte", "Antwort holen"], ["warte", "Echte Namen einsetzen und speichern"]];
  statusSetzen(zeilen);
  try {
    let roh = "";
    if (text) roh += text + "\n\n";
    doks.forEach(d => { SITZUNG.dokNr++; roh += "--- Dokument " + SITZUNG.dokNr + " ---\n" + d.text.trim() + "\n\n"; });
    if (frage) roh += (text || doks.length ? "Frage/Auftrag: " : "") + frage;
    roh = roh.trim();

    const eigene = (EINST.eigene || "").split(/\r?\n/).map(s => s.trim()).filter(s => s.length >= 2);
    const vorher = Object.keys(SITZUNG.karte).length;
    const r = ShieldEngine.anonymisieren(roh, eigene, SITZUNG.karte, { datum: EINST.datum });
    SITZUNG.karte = r.karte;
    const neu = Object.keys(r.karte).length - vorher;
    const gesendet = (EINST.hinweis && !SITZUNG.hinweisGesendet ? ShieldEngine.hinweisKI : "") + r.text;
    zeilen[0] = ["ok", neu + " Angabe" + (neu === 1 ? "" : "n") + " geschwärzt" + (vorher ? " (" + vorher + " schon bekannt)" : "")];
    const heikel = ShieldEngine.heikleThemen(roh);
    if (heikel.length) zeilen.splice(1, 0, ["wf", "Heikle Themen erkannt: " + heikel.join(", ") + " – Vorschau prüfen"]);
    statusSetzen(zeilen);

    const basis = { frage, text, doks: doks.map(d => d.name), gesendet };
    if (EINST.ki === "universal") return universalStart(basis);

    const iSend = zeilen.findIndex(z => z[1] === "An die KI senden");
    zeilen[iSend] = ["lauf", "An die KI senden …"]; statusSetzen(zeilen);
    const antwortP = anKI(gesendet);
    zeilen[iSend] = ["ok", "An die KI gesendet"]; zeilen[iSend + 1] = ["lauf", "KI schreibt die Antwort …"]; statusSetzen(zeilen);
    const antwort = await antwortP;
    if (meinLauf !== lauf) return;                              // abgebrochen
    SITZUNG.hinweisGesendet = true;
    zeilen[iSend + 1] = ["ok", "Antwort erhalten"]; zeilen[iSend + 2] = ["lauf", "Echte Namen einsetzen …"]; statusSetzen(zeilen);
    await abschliessen(basis, antwort);
  } catch (e) {
    if (meinLauf !== lauf) return;
    fehlerZeigen(e.message || String(e));
  }
}

/* Live: Antwort erscheint in Shield, während die KI schreibt (schon mit echten Namen) */
function liveZeigen(text) {
  const l = $("liveAntwort");
  l.innerHTML = '<div class="antw-kopf"><span>KI schreibt … (live, mit echten Namen)</span><span class="spin">◌</span></div>' +
    ShieldEngine.deanonTeile(text, SITZUNG.karte).map(t => t.t !== undefined ? esc(t.t) : '<span class="echt">' + esc(t.echt) + '</span>').join("");
  l.hidden = false;
  l.scrollTop = l.scrollHeight;
}
if (IST_ERW) chrome.runtime.onMessage.addListener(msg => {
  if (msg && msg.shield && msg.typ === "teil" && !$("arbeitet").hidden) liveZeigen(msg.text);
});

function fehlerZeigen(t) {
  $("liveAntwort").hidden = true;
  $("arbeitet").hidden = true; $("eingabe").hidden = false; stufe(SITZUNG.eintraege.length ? 3 : 1);
  const d = document.createElement("div"); d.className = "fehlerbox"; d.textContent = "✕ " + t;
  $("verlauf").appendChild(d); d.scrollIntoView({ behavior: "smooth", block: "nearest" });
  setTimeout(() => d.remove(), 15000);
}

async function abschliessen(basis, antwortRoh) {
  const e = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    zeit: new Date().toISOString(),
    titel: (basis.frage || basis.text || basis.doks.join(", ") || "Anfrage").replace(/\s+/g, " ").slice(0, 70),
    frage: basis.frage, text: basis.text, doks: basis.doks,
    gesendet: basis.gesendet, antwortRoh, karte: Object.assign({}, SITZUNG.karte),
    ki: EINST.ki === "universal" ? "Universal" : ($("kiAnzeige").textContent.replace("✓ verbunden mit ", "") || "")
  };
  SITZUNG.eintraege.push(e);
  UEB.unshift(e);
  ShieldLizenz.zaehlen(LIZ); await speicher.set("lizenz_status", LIZ); bannerZeigen();
  await speicher.set("uebersicht", UEB);
  // Eingabe leeren, Antwort zeigen
  $("textFeld").value = ""; $("frageFeld").value = ""; DOKS = []; dokListeZeigen();
  $("frageFeld").placeholder = "Weitere Frage oder weiterer Auftrag (gleiche Zuordnung), z. B. «Mach es kürzer»";
  $("liveAntwort").hidden = true; $("liveAntwort").innerHTML = "";
  $("arbeitet").hidden = true; $("universal").hidden = true; $("eingabe").hidden = false; $("fussArbeit").hidden = false;
  stufe(3);
  eintragZeigen(e);
  werbungNachAntwort();
  uebersichtZeigen();
  const offen = ShieldEngine.offenePlatzhalter(ShieldEngine.deanonymisieren(antwortRoh, e.karte));
  if (offen.length) meldung("Hinweis: " + offen.length + " Platzhalter konnte(n) nicht zugeordnet werden.", 5000);
}

function antwortHTML(e) {
  return ShieldEngine.deanonTeile(e.antwortRoh, e.karte)
    .map(t => t.t !== undefined ? esc(t.t) : '<span class="echt" title="von Shield eingesetzt (' + esc(t.ph) + ')">' + esc(t.echt) + '</span>').join("");
}
const antwortEcht = e => ShieldEngine.deanonymisieren(e.antwortRoh, e.karte);

function eintragZeigen(e) {
  const d = document.createElement("div"); d.className = "eintrag";
  d.innerHTML =
    '<div class="frage">Frage/Auftrag ' + SITZUNG.eintraege.length + ' · ' + datum(e.zeit) + ' · ✓ gespeichert' +
    (e.doks.length ? ' · 📄 ' + esc(e.doks.join(", ")) : '') + (e.frage ? '<br>«' + esc(e.frage.slice(0, 140)) + '»' : '') + '</div>' +
    '<div class="antw"><div class="antw-kopf"><span>Antwort · mit echten Namen</span><span>🛡 entschwärzt</span></div>' + antwortHTML(e) + '</div>' +
    '<div class="antw-knoepfe"><button class="gross w" data-a="kop">📋 Kopieren</button><button class="gross w" data-a="spe">💾 Speichern</button></div>' +
    '<button class="link" data-a="vor">👁 Vorschau geschwärzt (was die KI bekam)</button>';
  d.querySelector('[data-a="kop"]').onclick = async () => meldung(await kopieren(antwortEcht(e)) ? "Antwort kopiert (mit echten Namen)." : "Kopieren nicht möglich.");
  d.querySelector('[data-a="spe"]').onclick = () => speichernDatei([e], "doc");
  d.querySelector('[data-a="vor"]').onclick = () => vorschau(e);
  $("verlauf").appendChild(d);
  d.scrollIntoView({ behavior: "smooth", block: "start" });
}

function vorschau(e) {
  $("vorText").innerHTML = esc(e.gesendet).replace(/\[[^\]]+ \d+\]/g, m => '<span class="ph">' + m + '</span>');
  $("vorKarte").innerHTML = Object.entries(e.karte).map(([k, v]) => '<span class="ph">' + esc(k) + '</span><span>' + esc(v) + '</span>').join("") || "<span>–</span>";
  oeffne("fensterVorschau");
}

/* ---------- Universal-Weg ---------- */
let UNI = null;
async function universalStart(basis) {
  UNI = basis;
  const ok = await kopieren(basis.gesendet);
  $("arbeitet").hidden = true; $("universal").hidden = false; $("uniAntwort").value = "";
  meldung(ok ? "Geschwärzter Text ist in der Zwischenablage." : "Kopieren nicht möglich – bitte «nochmals kopieren».");
  $("uniAntwort").focus();
}
$("knopfUniNochmal").onclick = async () => { if (UNI) meldung(await kopieren(UNI.gesendet) ? "Nochmals kopiert." : "Kopieren nicht möglich."); };
$("knopfUniFertig").onclick = async () => {
  const a = $("uniAntwort").value.trim();
  if (!a) return meldung("Bitte zuerst die Antwort der KI einfügen.");
  SITZUNG.hinweisGesendet = true;
  await abschliessen(UNI, a); UNI = null;
};

/* ---------- Dokumente ---------- */
async function dateienHinzu(liste) {
  for (const f of liste) {
    const d = { id: Math.random().toString(36).slice(2), name: f.name, laedt: true };
    DOKS.push(d); dokListeZeigen();
    try {
      const r = await ShieldDokBasis.lesen(f, { fortschritt: (a, m) => { d.info = m; dokListeZeigen(); } });
      d.text = r.text; d.dok = r.dok || null; d.warnungen = r.warnungen || [];
      if (!d.text.trim() && !(d.dok && d.dok.seiten.some(s => s.hatBild))) d.fehler = "kein Text gefunden";
    }
    catch (e) { d.fehler = e.message; }
    d.laedt = false; d.info = ""; dokListeZeigen();
    if (d.fehler) meldung(d.name + ": " + d.fehler, 6000);
    else if (d.warnungen && d.warnungen.length) meldung(d.name + ": " + d.warnungen[0], 6000);
  }
}
/* Klare Rückmeldung: Dokument wird gelesen / ist bereit – und was jetzt zu tun ist */
function dokBereitZeigen() {
  const box = $("dokBereit"), laeuft = DOKS.filter(d => d.laedt), ok = DOKS.filter(d => !d.laedt && !d.fehler && d.text);
  if (laeuft.length) {
    box.className = "dok-bereit laedt"; box.hidden = false;
    box.innerHTML = "Dokument wird gelesen …<small>" + esc(laeuft[0].info || "bitte einen Moment") + "</small>";
  } else if (ok.length) {
    const frageLeer = !$("frageFeld").value.trim();
    box.className = "dok-bereit"; box.hidden = false;
    box.innerHTML = (ok.length === 1 ? "Dokument bereit" : ok.length + " Dokumente bereit") + " – persönliche Daten werden beim Senden geschwärzt." +
      "<small>" + (frageLeer ? "Jetzt unten eingeben, was die KI tun soll, und «Ausführen» klicken." : "Jetzt «Ausführen» klicken.") + "</small>";
    $("frageFeld").classList.toggle("dran", frageLeer);
    if (frageLeer && document.activeElement !== $("textFeld")) $("frageFeld").focus();
  } else { box.hidden = true; $("frageFeld").classList.remove("dran"); }
  $("frageFeld").placeholder = ok.length ? "Was soll die KI mit dem Dokument tun? z. B. «Fasse zusammen» oder «Schreibe eine Antwort»"
    : (SITZUNG.eintraege && SITZUNG.eintraege.length ? $("frageFeld").placeholder : "Frage oder Auftrag an die KI, z. B. «Schreibe daraus eine freundliche Mahnung»");
}
$("frageFeld").addEventListener("input", () => { if (DOKS.length) dokBereitZeigen(); });

function dokListeZeigen() {
  $("dokListe").innerHTML = DOKS.map(d => '<span class="dok' + (d.fehler ? ' fehler' : d.laedt ? '' : ' ok') + '" title="' + esc(d.fehler || "") + '">' +
    (d.laedt ? '<span class="spin">◌</span>' : d.fehler ? "✕" : "📄") + ' ' + esc(d.name) +
    (d.laedt && d.info ? ' <small>' + esc(d.info) + '</small>' : '') +
    (d.text ? ' <small>(' + (d.dok && d.dok.seiten.length > 1 ? d.dok.seiten.length + ' Seiten, ' : '') + d.text.length.toLocaleString("de-CH") + ' Zeichen)</small>' : '') +
    (d.dok && d.dok.seiten.some(s => s.hatBild) ? '<button class="dok-kopie" data-kopie="' + d.id + '" title="Schwarze Balken prüfen und geschwärzte Kopie als PDF oder JPG speichern">Geschwärzte Kopie</button>' : '') +
    '<button data-weg="' + d.id + '" title="entfernen">✕</button></span>').join("");
  dokBereitZeigen();
  $("dokListe").querySelectorAll("[data-kopie]").forEach(b => b.onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("editor.html?id=" + b.dataset.kopie) }));
  $("dokListe").querySelectorAll("[data-weg]").forEach(b => b.onclick = () => { DOKS = DOKS.filter(x => x.id !== b.dataset.weg); dokListeZeigen(); });
}
$("dateiWahl").accept = ShieldDokBasis.akzeptiert;
$("dateiWahl").onchange = e => { dateienHinzu([...e.target.files]); e.target.value = ""; };
const ablage = $("ablage");
["dragenter", "dragover"].forEach(t => document.addEventListener(t, e => { e.preventDefault(); ablage.classList.add("drueber"); }));
["dragleave", "drop"].forEach(t => document.addEventListener(t, e => { e.preventDefault(); if (t === "drop" || e.target === document.documentElement) ablage.classList.remove("drueber"); }));
document.addEventListener("drop", async e => {
  if (!e.dataTransfer || !e.dataTransfer.files.length) return;
  if (!$("fensterLizenz").hidden) return lizenzUebernehmen(await e.dataTransfer.files[0].text());   // Lizenz-Datei
  dateienHinzu([...e.dataTransfer.files]);
});

/* ---------- Übersicht ---------- */
function uebersichtZeigen() {
  $("anzUeb").textContent = UEB.length;
  const q = $("suche").value.trim().toLowerCase();
  const liste = UEB.filter(e => !q || (e.titel + " " + antwortEcht(e) + " " + (e.frage || "")).toLowerCase().includes(q));
  $("ueberInfo").textContent = WAHL.size ? WAHL.size + " ausgewählt" : "";
  $("alleWahl").checked = liste.length > 0 && liste.every(e => WAHL.has(e.id));
  if (!liste.length) { $("uebListe").innerHTML = '<div class="leer">' + (UEB.length ? "Nichts gefunden." : "Noch keine Antworten gespeichert.<br>Jede Antwort wird hier automatisch abgelegt.") + '</div>'; return; }
  $("uebListe").innerHTML = liste.map(e => '<div class="wisch" data-wid="' + e.id + '"><div class="wisch-l">Kopieren</div><div class="wisch-r">Löschen</div><label class="ueb"><input type="checkbox" data-id="' + e.id + '"' + (WAHL.has(e.id) ? " checked" : "") + '>' +
    '<span class="t"><b>' + esc(e.titel) + '</b><small>' + datum(e.zeit) + (e.ki ? ' · ' + esc(e.ki) : '') + (e.doks.length ? ' · 📄 ' + e.doks.length : '') + '</small>' +
    '<span class="vorsch">' + esc(antwortEcht(e).slice(0, 220)) + '</span></span></label></div>').join("");
  $("uebListe").querySelectorAll(".wisch").forEach(wischEinrichten);
  $("uebListe").querySelectorAll("input[data-id]").forEach(c => c.onchange = () => { c.checked ? WAHL.add(c.dataset.id) : WAHL.delete(c.dataset.id); $("ueberInfo").textContent = WAHL.size ? WAHL.size + " ausgewählt" : ""; });
}
$("suche").oninput = uebersichtZeigen;
$("alleWahl").onchange = () => {
  const q = $("suche").value.trim().toLowerCase();
  UEB.filter(e => !q || (e.titel + " " + antwortEcht(e)).toLowerCase().includes(q)).forEach(e => $("alleWahl").checked ? WAHL.add(e.id) : WAHL.delete(e.id));
  uebersichtZeigen();
};
function gewaehlte() {
  const l = UEB.filter(e => WAHL.has(e.id));
  if (!l.length) meldung("Bitte zuerst Antworten anhaken (oder «alle auswählen»).");
  return l;
}
function alsText(liste) {
  return liste.map(e => datum(e.zeit) + " – " + e.titel + "\n\n" + (e.frage ? "Frage/Auftrag: " + e.frage + "\n" : "") +
    (e.doks.length ? "Dokumente: " + e.doks.join(", ") + "\n" : "") + "\nAntwort:\n" + antwortEcht(e) + "\n").join("\n------------------------------\n\n");
}
function alsHTML(liste) {
  const teile = liste.map(e => '<h2 style="font-size:14pt;color:#2563EB;margin:18pt 0 4pt">' + esc(e.titel) + '</h2>' +
    '<p style="color:#64748B;font-size:9pt;margin:0 0 6pt">' + datum(e.zeit) + (e.doks.length ? ' · Dokumente: ' + esc(e.doks.join(", ")) : '') + '</p>' +
    (e.frage ? '<p><b>Frage/Auftrag:</b> ' + esc(e.frage) + '</p>' : '') +
    '<div style="white-space:pre-wrap">' + esc(antwortEcht(e)) + '</div>').join('<hr style="border:0;border-top:1px solid #E5E7EB;margin:16pt 0">');
  return '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>Shield-Antworten</title></head>' +
    '<body style="font-family:Segoe UI,Arial;font-size:11pt;line-height:1.45;color:#0F172A"><h1 style="font-size:16pt">Antworten (DEXXUS Shield)</h1>' + teile + '</body></html>';
}
async function speichernDatei(liste, format) {
  if (!liste.length) return;
  const stamp = new Date().toISOString().slice(0, 10);
  if (format === "pdf") {
    const w = window.open("", "_blank");
    if (!w) return meldung("Fenster wurde blockiert.");
    w.document.write(alsHTML(liste)); w.document.close();
    setTimeout(() => { w.focus(); w.print(); }, 400);
    return meldung("Im Druckfenster «Als PDF speichern» wählen.", 5000);
  }
  const blob = format === "txt" ? new Blob(["﻿" + alsText(liste)], { type: "text/plain;charset=utf-8" })
                                : new Blob([alsHTML(liste)], { type: "application/msword" });
  const name = "Shield-Antworten_" + stamp + "." + format;
  const url = URL.createObjectURL(blob);
  try {
    if (IST_ERW && chrome.downloads) await chrome.downloads.download({ url, filename: name, saveAs: true });
    else { const a = document.createElement("a"); a.href = url; a.download = name; a.click(); }
  } catch (e) { meldung("Speichern abgebrochen."); }
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
$("knopfKopAlle").onclick = async () => { const l = gewaehlte(); if (l.length) meldung(await kopieren(alsText(l)) ? l.length + " Antwort(en) kopiert." : "Kopieren nicht möglich."); };
const FORMAT_NAME = { doc: "Word", pdf: "PDF", txt: "Text" };
document.querySelectorAll("#formatWahl button").forEach(b => b.onclick = () => {
  $("format").value = b.dataset.f;
  document.querySelectorAll("#formatWahl button").forEach(x => x.classList.toggle("an", x === b));
  $("knopfSpeichern").textContent = "Als " + FORMAT_NAME[b.dataset.f] + " speichern";
});
$("knopfSpeichern").onclick = () => { const l = gewaehlte(); if (l.length) speichernDatei(l, $("format").value); };
$("knopfLoeschen").onclick = async () => {
  const l = gewaehlte(); if (!l.length) return;
  if (!confirm(l.length + " Antwort(en) endgültig löschen?")) return;
  UEB = UEB.filter(e => !WAHL.has(e.id)); WAHL.clear(); await speicher.set("uebersicht", UEB); uebersichtZeigen();
};

/* ---------- Wischen (Touchscreen, Touchpad, Maus ziehen) ----------
   Übersicht: Antwort nach rechts = kopieren, nach links = löschen (mit Rückfrage).
   Ganze Fläche: nach links/rechts = Reiter «Arbeiten» / «Übersicht» wechseln. */
const WISCH_GRENZE = 90;
async function wischAktion(id, richtung) {
  const e = UEB.find(x => x.id === id); if (!e) return;
  if (richtung > 0) { meldung(await kopieren(antwortEcht(e)) ? "Antwort kopiert." : "Kopieren nicht möglich."); return; }
  if (!confirm("Diese Antwort löschen? – «" + e.titel + "»")) return;
  UEB = UEB.filter(x => x.id !== id); WAHL.delete(id); await speicher.set("uebersicht", UEB); uebersichtZeigen(); meldung("Antwort gelöscht.");
}
function wischEinrichten(el) {
  const karte = el.querySelector(".ueb");
  let start = null, dx = 0, aktiv = false;
  const setzen = x => { dx = x; karte.style.transform = "translateX(" + x + "px)"; el.classList.toggle("links", x < -20); el.classList.toggle("rechts", x > 20); };
  const fertig = () => {
    karte.style.transition = "transform .18s"; const d = dx; setzen(0);
    setTimeout(() => { karte.style.transition = ""; el.classList.remove("links", "rechts"); }, 200);
    if (Math.abs(d) >= WISCH_GRENZE) wischAktion(el.dataset.wid, d);
  };
  el.addEventListener("pointerdown", e => { if (e.button !== 0) return; start = { x: e.clientX, y: e.clientY }; aktiv = false; });
  el.addEventListener("pointermove", e => {
    if (!start) return;
    const x = e.clientX - start.x, y = e.clientY - start.y;
    if (!aktiv && Math.abs(x) > 12 && Math.abs(x) > Math.abs(y) * 1.5) { aktiv = true; el.setPointerCapture(e.pointerId); }
    if (aktiv) { e.preventDefault(); setzen(Math.max(-160, Math.min(160, x))); }
  });
  const ende = e => { if (aktiv) { e.preventDefault(); fertig(); el.dataset.gewischt = "1"; setTimeout(() => delete el.dataset.gewischt, 50); } start = null; aktiv = false; };
  el.addEventListener("pointerup", ende); el.addEventListener("pointercancel", ende);
  el.addEventListener("click", e => { if (el.dataset.gewischt) { e.preventDefault(); e.stopPropagation(); } }, true);
  // Touchpad: zwei Finger seitwärts
  let rad = 0, radTimer = null;
  el.addEventListener("wheel", e => {
    if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
    e.preventDefault(); e.stopPropagation();
    rad -= e.deltaX; setzen(Math.max(-160, Math.min(160, rad)));
    clearTimeout(radTimer); radTimer = setTimeout(() => { fertig(); rad = 0; }, 140);
  }, { passive: false });
}
function reiterWechseln(name) { const b = document.querySelector('.reiter button[data-r="' + name + '"]'); if (b) b.click(); }
(function () {
  let start = null;
  const frei = t => !t.closest(".wisch, textarea, input, select, .fenster");
  document.addEventListener("touchstart", e => { const t = e.touches[0]; start = frei(e.target) ? { x: t.clientX, y: t.clientY } : null; }, { passive: true });
  document.addEventListener("touchend", e => {
    if (!start) return; const t = e.changedTouches[0], x = t.clientX - start.x, y = t.clientY - start.y; start = null;
    if (Math.abs(x) > 80 && Math.abs(x) > Math.abs(y) * 2) reiterWechseln(x < 0 ? "uebersicht" : "arbeiten");
  }, { passive: true });
  let rad = 0, sperre = false, radTimer = null;
  document.addEventListener("wheel", e => {
    if (sperre || Math.abs(e.deltaX) <= Math.abs(e.deltaY) * 1.5 || !frei(e.target)) return;
    rad += e.deltaX; clearTimeout(radTimer); radTimer = setTimeout(() => { rad = 0; }, 200);
    if (Math.abs(rad) > 120) { reiterWechseln(rad > 0 ? "uebersicht" : "arbeiten"); rad = 0; sperre = true; setTimeout(() => { sperre = false; }, 700); }
  }, { passive: true });
})();

/* ---------- Reiter, Knöpfe, Einstellungen ---------- */
document.querySelectorAll(".reiter button").forEach(b => b.onclick = () => {
  document.querySelectorAll(".reiter button").forEach(x => x.classList.toggle("an", x === b));
  document.querySelectorAll(".ansicht").forEach(a => a.classList.toggle("an", a.id === b.dataset.r));
  if (b.dataset.r === "uebersicht") uebersichtZeigen();
});
$("knopfAus").onclick = ausfuehren;
$("frageFeld").addEventListener("keydown", e => { if (e.key === "Enter" && e.ctrlKey) ausfuehren(); });
$("textFeld").addEventListener("keydown", e => { if (e.key === "Enter" && e.ctrlKey) ausfuehren(); });
$("knopfAbbruch").onclick = () => { lauf++; $("arbeitet").hidden = true; $("eingabe").hidden = false; stufe(SITZUNG.eintraege.length ? 3 : 1); meldung("Abgebrochen. (Die KI-Seite schreibt evtl. noch weiter.)"); };
$("knopfNeu").onclick = () => {
  if (!confirm("Neues Thema beginnen? Die bisherigen Antworten bleiben in der Übersicht. Tipp: In der KI auch einen neuen Chat öffnen.")) return;
  SITZUNG = neueSitzung(); $("verlauf").innerHTML = ""; $("fussArbeit").hidden = true; stufe(1);
  $("frageFeld").placeholder = "Frage oder Auftrag an die KI, z. B. «Schreibe daraus eine freundliche Mahnung»";
};
$("knopfHilfe").onclick = () => oeffne("fensterHilfe");
$("knopfEinst").onclick = () => {
  $("eKi").value = EINST.ki; $("eDatum").checked = EINST.datum; $("eHinweis").checked = EINST.hinweis; $("eEigene").value = EINST.eigene || "";
  oeffne("fensterEinst");
};
$("eSpeichern").onclick = async () => {
  EINST = { ki: $("eKi").value, datum: $("eDatum").checked, hinweis: $("eHinweis").checked, eigene: $("eEigene").value,
            farbe: document.body.dataset.farbe || "blau" };
  await speicher.set("einstellungen", EINST); $("fensterEinst").hidden = true; kiAnzeigen(); meldung("Gespeichert.");
};
$("eAllesLoeschen").onclick = async () => {
  if (!confirm("Wirklich ALLE gespeicherten Antworten löschen? Das kann nicht rückgängig gemacht werden.")) return;
  UEB = []; WAHL.clear(); await speicher.set("uebersicht", UEB); uebersichtZeigen(); meldung("Alle Antworten gelöscht.");
};

/* ---------- Start ---------- */
(async function start() {
  stufe(1);
  EINST = Object.assign(EINST, await speicher.get("einstellungen", {}));
  farbeSetzen(EINST.farbe);
  LIZ = Object.assign(LIZ, await speicher.get("lizenz_status", {}));
  if (!LIZ.start) { LIZ.start = ShieldLizenz.heute(); await speicher.set("lizenz_status", LIZ); }
  if (LIZ.lizenz && LIZ.lizenz.text) {                          // gespeicherte Lizenz bei jedem Start neu prüfen
    const r = await ShieldLizenz.pruefen(LIZ.lizenz.text);
    if (!r.ok && !(r.daten)) LIZ.lizenz = null;
  }
  bannerZeigen();
  UEB = await speicher.get("uebersicht", []);
  uebersichtZeigen(); kiAnzeigen();
  try { ShieldEngine.orteSetzen(await (await fetch("orte_ch.txt")).text()); }
  catch (e) { meldung("Ortsverzeichnis fehlt – Orte ohne PLZ werden nicht geschwärzt.", 5000); }
})();

/* Texterkennung im Hintergrund vorbereiten, damit Scans und Fotos sofort gelesen werden */
setTimeout(() => { try { window.ShieldDokumente && ShieldDokumente.vorwaermen().catch(() => {}); } catch (e) { /* später beim ersten Scan */ } }, 1200);
