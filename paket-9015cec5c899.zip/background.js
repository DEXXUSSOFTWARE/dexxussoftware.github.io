/* DEXXUS Shield – Hintergrund: Klick aufs Schild öffnet die Seitenleiste. */
function seitenleisteBeiKlick() {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
}
chrome.runtime.onInstalled.addListener(seitenleisteBeiKlick);
chrome.runtime.onStartup.addListener(seitenleisteBeiKlick);
seitenleisteBeiKlick();
